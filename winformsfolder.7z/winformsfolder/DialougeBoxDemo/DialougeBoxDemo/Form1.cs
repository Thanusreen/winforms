﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DialougeBoxDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMessage_Click(object sender, EventArgs e)
        {
         DialogResult result= MessageBox.Show("Mesage is displayed","MessageBox",MessageBoxButtons.OKCancel,MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                MessageBox.Show("OK BUTTON IS CLICKED","OK");

            }
            if (result == DialogResult.Cancel)
            {
                MessageBox.Show("CANCEL BUTTON CLICKED","Cancel");
            }
        }

        private void btnCustom_Click(object sender, EventArgs e)
        {
            CustomDialog CUSTOM = new CustomDialog();
            CUSTOM.ShowDialog();
        }
    }
}
