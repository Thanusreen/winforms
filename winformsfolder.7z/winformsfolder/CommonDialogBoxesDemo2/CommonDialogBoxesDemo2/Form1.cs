﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CommonDialogBoxesDemo2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnopenfiledialog_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string file = open.FileName;
                FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                string data=sr.ReadToEnd();
                txtData.Text= data;
                sr.Close();
            }
        }

        private void btncolordialog_Click(object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog();
            color.FullOpen = true;
            color.ShowHelp = true;
            if(color.ShowDialog()== System.Windows.Forms.DialogResult.OK)
            {
                txtData.BackColor = color.Color;
            }
        }

        private void btnFontDialog_Click(object sender, EventArgs e)
        {
            FontDialog font = new FontDialog();
            font.ShowEffects = true;
            font.ShowHelp = true;
            font.ShowColor = true;
            if(font.ShowDialog()== System.Windows.Forms.DialogResult.OK)
            {
                txtData.Font = font.Font;
                txtData.ForeColor = font.Color;
            }
        }
    }
}
