﻿namespace CommonDialogBoxesDemo2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnopenfiledialog = new System.Windows.Forms.Button();
            this.btncolordialog = new System.Windows.Forms.Button();
            this.btnFontDialog = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnopenfiledialog
            // 
            this.btnopenfiledialog.Location = new System.Drawing.Point(217, 3);
            this.btnopenfiledialog.Name = "btnopenfiledialog";
            this.btnopenfiledialog.Size = new System.Drawing.Size(123, 67);
            this.btnopenfiledialog.TabIndex = 0;
            this.btnopenfiledialog.Text = "Open File dialog";
            this.btnopenfiledialog.UseVisualStyleBackColor = true;
            this.btnopenfiledialog.Click += new System.EventHandler(this.btnopenfiledialog_Click);
            // 
            // btncolordialog
            // 
            this.btncolordialog.Location = new System.Drawing.Point(217, 76);
            this.btncolordialog.Name = "btncolordialog";
            this.btncolordialog.Size = new System.Drawing.Size(123, 67);
            this.btncolordialog.TabIndex = 1;
            this.btncolordialog.Text = "colordialog";
            this.btncolordialog.UseVisualStyleBackColor = true;
            this.btncolordialog.Click += new System.EventHandler(this.btncolordialog_Click);
            // 
            // btnFontDialog
            // 
            this.btnFontDialog.Location = new System.Drawing.Point(217, 149);
            this.btnFontDialog.Name = "btnFontDialog";
            this.btnFontDialog.Size = new System.Drawing.Size(123, 67);
            this.btnFontDialog.TabIndex = 2;
            this.btnFontDialog.Text = "FontDialog";
            this.btnFontDialog.UseVisualStyleBackColor = true;
            this.btnFontDialog.Click += new System.EventHandler(this.btnFontDialog_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(200, 244);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtData.Size = new System.Drawing.Size(218, 125);
            this.txtData.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 427);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.btnFontDialog);
            this.Controls.Add(this.btncolordialog);
            this.Controls.Add(this.btnopenfiledialog);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnopenfiledialog;
        private System.Windows.Forms.Button btncolordialog;
        private System.Windows.Forms.Button btnFontDialog;
        private System.Windows.Forms.TextBox txtData;
    }
}

