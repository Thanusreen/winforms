﻿namespace WindowsFormsDemo
{
    partial class EmployeeForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeForm1));
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblEmployeeid = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.txtEmployeeid = new System.Windows.Forms.TextBox();
            this.rdbMale = new System.Windows.Forms.RadioButton();
            this.rdbFemale = new System.Windows.Forms.RadioButton();
            this.rdblt20000 = new System.Windows.Forms.RadioButton();
            this.rdb40000to60000 = new System.Windows.Forms.RadioButton();
            this.rdb20000to40000 = new System.Windows.Forms.RadioButton();
            this.rdbgt60000 = new System.Windows.Forms.RadioButton();
            this.lblcity = new System.Windows.Forms.Label();
            this.citycombobox = new System.Windows.Forms.ComboBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeName.Location = new System.Drawing.Point(45, 65);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(121, 20);
            this.lblEmployeeName.TabIndex = 0;
            this.lblEmployeeName.Text = "EmployeeName";
            // 
            // lblEmployeeid
            // 
            this.lblEmployeeid.AutoSize = true;
            this.lblEmployeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeid.Location = new System.Drawing.Point(45, 124);
            this.lblEmployeeid.Name = "lblEmployeeid";
            this.lblEmployeeid.Size = new System.Drawing.Size(93, 20);
            this.lblEmployeeid.TabIndex = 1;
            this.lblEmployeeid.Text = "EmployeeId";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(45, 174);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(63, 20);
            this.lblGender.TabIndex = 2;
            this.lblGender.Text = "Gender";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalary.Location = new System.Drawing.Point(52, 245);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(53, 20);
            this.lblSalary.TabIndex = 3;
            this.lblSalary.Text = "Salary";
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(222, 62);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(192, 20);
            this.txtEmployeeName.TabIndex = 4;
            // 
            // txtEmployeeid
            // 
            this.txtEmployeeid.Location = new System.Drawing.Point(222, 121);
            this.txtEmployeeid.Name = "txtEmployeeid";
            this.txtEmployeeid.Size = new System.Drawing.Size(192, 20);
            this.txtEmployeeid.TabIndex = 5;
            // 
            // rdbMale
            // 
            this.rdbMale.AutoSize = true;
            this.rdbMale.Location = new System.Drawing.Point(16, 33);
            this.rdbMale.Name = "rdbMale";
            this.rdbMale.Size = new System.Drawing.Size(48, 17);
            this.rdbMale.TabIndex = 6;
            this.rdbMale.TabStop = true;
            this.rdbMale.Text = "Male";
            this.rdbMale.UseVisualStyleBackColor = true;
            // 
            // rdbFemale
            // 
            this.rdbFemale.AutoSize = true;
            this.rdbFemale.Location = new System.Drawing.Point(100, 33);
            this.rdbFemale.Name = "rdbFemale";
            this.rdbFemale.Size = new System.Drawing.Size(59, 17);
            this.rdbFemale.TabIndex = 7;
            this.rdbFemale.TabStop = true;
            this.rdbFemale.Text = "Female";
            this.rdbFemale.UseVisualStyleBackColor = true;
            // 
            // rdblt20000
            // 
            this.rdblt20000.AutoSize = true;
            this.rdblt20000.Location = new System.Drawing.Point(46, 24);
            this.rdblt20000.Name = "rdblt20000";
            this.rdblt20000.Size = new System.Drawing.Size(61, 17);
            this.rdblt20000.TabIndex = 8;
            this.rdblt20000.TabStop = true;
            this.rdblt20000.Text = "<20000";
            this.rdblt20000.UseVisualStyleBackColor = true;
            // 
            // rdb40000to60000
            // 
            this.rdb40000to60000.AutoSize = true;
            this.rdb40000to60000.Location = new System.Drawing.Point(33, 72);
            this.rdb40000to60000.Name = "rdb40000to60000";
            this.rdb40000to60000.Size = new System.Drawing.Size(100, 17);
            this.rdb40000to60000.TabIndex = 9;
            this.rdb40000to60000.TabStop = true;
            this.rdb40000to60000.Text = "40000 to 60000";
            this.rdb40000to60000.UseVisualStyleBackColor = true;
            // 
            // rdb20000to40000
            // 
            this.rdb20000to40000.AutoSize = true;
            this.rdb20000to40000.Location = new System.Drawing.Point(134, 24);
            this.rdb20000to40000.Name = "rdb20000to40000";
            this.rdb20000to40000.Size = new System.Drawing.Size(100, 17);
            this.rdb20000to40000.TabIndex = 10;
            this.rdb20000to40000.TabStop = true;
            this.rdb20000to40000.Text = "20000 to 40000";
            this.rdb20000to40000.UseVisualStyleBackColor = true;
            // 
            // rdbgt60000
            // 
            this.rdbgt60000.AutoSize = true;
            this.rdbgt60000.Location = new System.Drawing.Point(149, 72);
            this.rdbgt60000.Name = "rdbgt60000";
            this.rdbgt60000.Size = new System.Drawing.Size(61, 17);
            this.rdbgt60000.TabIndex = 11;
            this.rdbgt60000.TabStop = true;
            this.rdbgt60000.Text = ">60000";
            this.rdbgt60000.UseVisualStyleBackColor = true;
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.Location = new System.Drawing.Point(53, 364);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(32, 20);
            this.lblcity.TabIndex = 12;
            this.lblcity.Text = "city";
            // 
            // citycombobox
            // 
            this.citycombobox.FormattingEnabled = true;
            this.citycombobox.Items.AddRange(new object[] {
            "Pune",
            "Banglore",
            "Hyderabad",
            "Mumbai",
            "chennai"});
            this.citycombobox.Location = new System.Drawing.Point(210, 366);
            this.citycombobox.Name = "citycombobox";
            this.citycombobox.Size = new System.Drawing.Size(121, 21);
            this.citycombobox.TabIndex = 13;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(541, 415);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 14;
            this.btnsubmit.Text = "submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(492, 62);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbMale);
            this.groupBox1.Controls.Add(this.rdbFemale);
            this.groupBox1.Location = new System.Drawing.Point(222, 161);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(156, 53);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gender";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.rdblt20000);
            this.panel1.Controls.Add(this.rdb20000to40000);
            this.panel1.Controls.Add(this.rdb40000to60000);
            this.panel1.Controls.Add(this.rdbgt60000);
            this.panel1.Location = new System.Drawing.Point(222, 245);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(265, 100);
            this.panel1.TabIndex = 17;
            // 
            // EmployeeForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.citycombobox);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.txtEmployeeid);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.lblSalary);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblEmployeeid);
            this.Controls.Add(this.lblEmployeeName);
            this.Name = "EmployeeForm1";
            this.Text = "Form1";
           
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblEmployeeid;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.TextBox txtEmployeeid;
        private System.Windows.Forms.RadioButton rdbMale;
        private System.Windows.Forms.RadioButton rdbFemale;
        private System.Windows.Forms.RadioButton rdblt20000;
        private System.Windows.Forms.RadioButton rdb40000to60000;
        private System.Windows.Forms.RadioButton rdb20000to40000;
        private System.Windows.Forms.RadioButton rdbgt60000;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.ComboBox citycombobox;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
    }
}

