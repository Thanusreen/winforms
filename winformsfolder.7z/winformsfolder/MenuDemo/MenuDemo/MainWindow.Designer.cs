﻿namespace MenuDemo
{
    partial class txtMainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuItemForms = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemForm1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemForm2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemDialog = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemcolor = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemfont = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemMessageBox = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemPrintPReview = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemLayout = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemHorizontal = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemVertical = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemCascade = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemForms,
            this.MenuItemDialog,
            this.MenuItemLayout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(637, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuItemForms
            // 
            this.MenuItemForms.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemForm1,
            this.MenuItemForm2,
            this.MenuItemExit});
            this.MenuItemForms.Name = "MenuItemForms";
            this.MenuItemForms.Size = new System.Drawing.Size(52, 20);
            this.MenuItemForms.Text = "Forms";
            // 
            // MenuItemForm1
            // 
            this.MenuItemForm1.Name = "MenuItemForm1";
            this.MenuItemForm1.Size = new System.Drawing.Size(108, 22);
            this.MenuItemForm1.Text = "Form1";
            this.MenuItemForm1.Click += new System.EventHandler(this.MenuItemForm1_Click);
            // 
            // MenuItemForm2
            // 
            this.MenuItemForm2.Name = "MenuItemForm2";
            this.MenuItemForm2.Size = new System.Drawing.Size(108, 22);
            this.MenuItemForm2.Text = "Form2";
            this.MenuItemForm2.Click += new System.EventHandler(this.MenuItemForm2_Click);
            // 
            // MenuItemExit
            // 
            this.MenuItemExit.Name = "MenuItemExit";
            this.MenuItemExit.Size = new System.Drawing.Size(108, 22);
            this.MenuItemExit.Text = "Exit";
            this.MenuItemExit.Click += new System.EventHandler(this.MenuItemExit_Click);
            // 
            // MenuItemDialog
            // 
            this.MenuItemDialog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemcolor,
            this.MenuItemfont,
            this.MenuItemMessageBox,
            this.MenuItemPrintPReview});
            this.MenuItemDialog.Name = "MenuItemDialog";
            this.MenuItemDialog.Size = new System.Drawing.Size(72, 20);
            this.MenuItemDialog.Text = "DialogBox";
            // 
            // MenuItemcolor
            // 
            this.MenuItemcolor.Name = "MenuItemcolor";
            this.MenuItemcolor.Size = new System.Drawing.Size(140, 22);
            this.MenuItemcolor.Text = "color";
            this.MenuItemcolor.Click += new System.EventHandler(this.MenuItemcolor_Click);
            // 
            // MenuItemfont
            // 
            this.MenuItemfont.Name = "MenuItemfont";
            this.MenuItemfont.Size = new System.Drawing.Size(140, 22);
            this.MenuItemfont.Text = "font";
            this.MenuItemfont.Click += new System.EventHandler(this.MenuItemfont_Click);
            // 
            // MenuItemMessageBox
            // 
            this.MenuItemMessageBox.Name = "MenuItemMessageBox";
            this.MenuItemMessageBox.Size = new System.Drawing.Size(140, 22);
            this.MenuItemMessageBox.Text = "messagebox";
            this.MenuItemMessageBox.Click += new System.EventHandler(this.MenuItemMessageBox_Click);
            // 
            // MenuItemPrintPReview
            // 
            this.MenuItemPrintPReview.Name = "MenuItemPrintPReview";
            this.MenuItemPrintPReview.Size = new System.Drawing.Size(140, 22);
            this.MenuItemPrintPReview.Text = "printpreview";
            this.MenuItemPrintPReview.Click += new System.EventHandler(this.MenuItemPrintPReview_Click);
            // 
            // MenuItemLayout
            // 
            this.MenuItemLayout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemHorizontal,
            this.MenuItemVertical,
            this.MenuItemCascade});
            this.MenuItemLayout.Name = "MenuItemLayout";
            this.MenuItemLayout.Size = new System.Drawing.Size(55, 20);
            this.MenuItemLayout.Text = "Layout";
            // 
            // MenuItemHorizontal
            // 
            this.MenuItemHorizontal.Name = "MenuItemHorizontal";
            this.MenuItemHorizontal.Size = new System.Drawing.Size(129, 22);
            this.MenuItemHorizontal.Text = "Horizontal";
            this.MenuItemHorizontal.Click += new System.EventHandler(this.MenuItemHorizontal_Click);
            // 
            // MenuItemVertical
            // 
            this.MenuItemVertical.Name = "MenuItemVertical";
            this.MenuItemVertical.Size = new System.Drawing.Size(129, 22);
            this.MenuItemVertical.Text = "vertical";
            this.MenuItemVertical.Click += new System.EventHandler(this.MenuItemVertical_Click);
            // 
            // MenuItemCascade
            // 
            this.MenuItemCascade.Name = "MenuItemCascade";
            this.MenuItemCascade.Size = new System.Drawing.Size(129, 22);
            this.MenuItemCascade.Text = "cascade";
            this.MenuItemCascade.Click += new System.EventHandler(this.MenuItemCascade_Click);
            // 
            // txtMainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 252);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "txtMainWindow";
            this.Text = "MainWindow";
            this.Load += new System.EventHandler(this.txtMainWindow_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItemForms;
        private System.Windows.Forms.ToolStripMenuItem MenuItemForm1;
        private System.Windows.Forms.ToolStripMenuItem MenuItemForm2;
        private System.Windows.Forms.ToolStripMenuItem MenuItemExit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDialog;
        private System.Windows.Forms.ToolStripMenuItem MenuItemcolor;
        private System.Windows.Forms.ToolStripMenuItem MenuItemfont;
        private System.Windows.Forms.ToolStripMenuItem MenuItemMessageBox;
        private System.Windows.Forms.ToolStripMenuItem MenuItemPrintPReview;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLayout;
        private System.Windows.Forms.ToolStripMenuItem MenuItemHorizontal;
        private System.Windows.Forms.ToolStripMenuItem MenuItemVertical;
        private System.Windows.Forms.ToolStripMenuItem MenuItemCascade;
    }
}

